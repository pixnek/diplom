## mspgack
https://github.com/msgpack/msgpack-python
