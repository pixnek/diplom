Scenes
------

This folder contains several scenes, where each of them a glTF 2.0 feature is introduced.  
Because of their simplicity, they are also a reference on how to implement a glTF 2.0 material in Blender. Finally, also for developers and glTF 2.0 integrators the examples can help to develop and debug the own system, as the exported output is still manageable by human.  
The scenes are also used for the validation tests.