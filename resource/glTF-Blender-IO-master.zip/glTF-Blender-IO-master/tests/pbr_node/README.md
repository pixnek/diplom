PBR node
--------

In Blender, link item 'NodeTree/glTF Metallic Roughness' or 'NodeTree/glTF Specular Glossiness' from the glTF2.blend file. gltf2_Principled.blend is for Blender 2.79 and later versions.  
More on this can be found in the user documentation.
