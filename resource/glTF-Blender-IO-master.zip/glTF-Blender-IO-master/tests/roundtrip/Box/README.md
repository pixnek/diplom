# Box
## License Information

Donated by [Cesium](http://cesiumjs.org/) for glTF testing.